﻿using Microsoft.AspNetCore.Identity;
using RestaurantManagement.Models.ApplicationIdentities;
using RestaurantManagement.Models.Consts;
using RestaurantManagement.Models.Enums;

namespace RestaurantManagement.Data.DataSeeds
{
    public static class DataSeeder
    {
        public static async Task SeedAsync(IServiceProvider serviceProvider)
        {
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            var roleManager = serviceProvider.GetRequiredService<RoleManager<ApplicationRole>>();

            if (!await roleManager.RoleExistsAsync(SD.Role_Admin))
            {
                await roleManager.CreateAsync(new ApplicationRole(SD.Role_Admin, "Administrator Role"));
            }

            if (!await roleManager.RoleExistsAsync(SD.Role_User))
            {
                await roleManager.CreateAsync(new ApplicationRole(SD.Role_User, "Defautl User Role"));
            }

            var emailAdmin = "admin@example.com";
            var adminUser = await userManager.FindByEmailAsync(emailAdmin);

            if (adminUser == null)
            {
                var newAdmin = new ApplicationUser
                {
                    FullName = "Admin User",
                    UserName = emailAdmin,
                    Email = emailAdmin,
                    EmailConfirmed = true,
                };

                var result = await userManager.CreateAsync(newAdmin, "Admin@123");

                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(newAdmin, SD.Role_Admin);
                }
            }
        }
    }
}
