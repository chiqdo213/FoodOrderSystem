﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Data.Configurations
{
    public class RemarkConfiguration : IEntityTypeConfiguration<Remark>
    {
        public void Configure(EntityTypeBuilder<Remark> builder)
        {
            builder.ToTable("Remarks");

            builder.HasKey(r => r.Id);

            builder.Property(r => r.Status)
                .HasMaxLength(50);

            builder.Property(r => r.RemarkText)
                .IsRequired()
                .HasMaxLength(500);

            builder.Property(r => r.RemarkDate)
                .IsRequired()
                .HasDefaultValueSql("GETDATE()");

        }
    }
}