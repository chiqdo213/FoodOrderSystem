﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Data.Configurations
{
    public class DishConfiguration : IEntityTypeConfiguration<Dish>
    {
        public void Configure(EntityTypeBuilder<Dish> builder)
        {
            builder.ToTable("Dishes");

            builder.HasKey(d => d.Id);

            builder.Property(d => d.Title)
                .IsRequired()
                .HasMaxLength(100);

            builder.Property(d => d.Slogan)
                .HasMaxLength(200);

            builder.Property(d => d.Price)
                .IsRequired()
                .HasColumnType("decimal(18,2)");

            builder.Property(d => d.Img)
                .HasMaxLength(255);

            builder.HasMany(d => d.OrderItems)
                .WithOne(o => o.Dish)
                .HasForeignKey(o => o.DishId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}