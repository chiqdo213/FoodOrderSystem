﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Data.Configurations
{
    public class CartItemConfiguration : IEntityTypeConfiguration<CartItem>
    {
        public void Configure(EntityTypeBuilder<CartItem> builder)
        {
            builder.HasKey(ci => ci.Id);

            builder.HasOne(ci => ci.Cart)
                   .WithMany(c => c.CartItems)
                   .HasForeignKey(ci => ci.CartId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.HasOne(ci => ci.Dish)
                   .WithMany()
                   .HasForeignKey(ci => ci.DishId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.Property(ci => ci.Quantity)
                   .HasDefaultValue(1)
                   .IsRequired();
        }
    }
}
