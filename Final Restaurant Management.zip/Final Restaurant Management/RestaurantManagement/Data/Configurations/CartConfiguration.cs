﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Data.Configurations
{
    public class CartConfiguration : IEntityTypeConfiguration<Cart>
    {
        public void Configure(EntityTypeBuilder<Cart> builder)
        {
            builder.HasKey(c => c.Id);

            builder.HasOne(c => c.ApplicationUser)
                   .WithMany()
                   .HasForeignKey(c => c.ApplicationUserId)
                   .OnDelete(DeleteBehavior.Cascade);

            builder.Property(c => c.CreatedDate)
                   .HasDefaultValueSql("GETDATE()");
        }
    }
}