﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Data.Configurations
{
    public class RestaurantConfiguration : IEntityTypeConfiguration<Restaurant>
    {
        public void Configure(EntityTypeBuilder<Restaurant> builder)
        {
            builder.ToTable("Restaurants");

            builder.HasKey(r => r.Id);

            builder.Property(r => r.Title)
                .IsRequired()
                .HasMaxLength(100);

            builder.Property(r => r.Email)
                .HasMaxLength(100);

            builder.Property(r => r.Phone)
                .HasMaxLength(20);

            builder.Property(r => r.WebsiteUrl)
                .HasMaxLength(255);

            builder.Property(r => r.OpenDays)
                .HasMaxLength(100);

            builder.Property(r => r.Address)
                .HasMaxLength(255);

            builder.Property(r => r.ImageUrl)
                .HasMaxLength(255);

            builder.Property(r => r.CreatedDate)
                .IsRequired()
                .HasDefaultValueSql("GETDATE()");


            builder.HasMany(r => r.Dishes)
                .WithOne(d => d.Restaurant)
                .HasForeignKey(d => d.RestaurantId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}