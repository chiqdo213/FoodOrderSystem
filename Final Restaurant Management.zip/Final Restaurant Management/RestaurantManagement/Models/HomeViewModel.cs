﻿using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Models
{
    public class HomeViewModel
    {
        public List<Dish> Dishes { get; set; }
        public List<Restaurant> Restaurants { get; set; }
    }
}
