﻿using Microsoft.AspNetCore.Identity;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Models.ApplicationIdentities
{
    public class ApplicationUser : IdentityUser<Guid>
    {
        public string? FullName { get; set; }
        public string? Address { get; set; }

        public ICollection<Order> Orders { get; set; } = new List<Order>();
    }
}
