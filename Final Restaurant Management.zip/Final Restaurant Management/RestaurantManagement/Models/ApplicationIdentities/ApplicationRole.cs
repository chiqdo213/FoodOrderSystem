﻿using Microsoft.AspNetCore.Identity;

namespace RestaurantManagement.Models.ApplicationIdentities
{
    public class ApplicationRole : IdentityRole<Guid>
    {
        public string? Description { get; set; }

        public ApplicationRole() : base()
        {

        }

        public ApplicationRole(string roleName, string description) : base(roleName)
        {
            Description = description;
        }
    }
}
