﻿namespace RestaurantManagement.Models.Consts
{
    public static class SD
    {
        public const string Role_Admin = "Admin";
        public const string Role_User = "User";

        public const string StatusPending = "Pending";
        public const string StatusApproved = "Approved";
        public const string StatusCompleted = "Completed";
        public const string StatusCanceled = "Canceled";
    }
}
