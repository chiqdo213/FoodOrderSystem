﻿using RestaurantManagement.Models.ApplicationIdentities;

namespace RestaurantManagement.Models.Entities
{
    public class Cart
    {
        public int Id { get; set; }
        public Guid ApplicationUserId { get; set; }
        public DateTime CreatedDate { get; set; }

        public ApplicationUser ApplicationUser { get; set; }
        public ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
    }
}