﻿namespace RestaurantManagement.Models.Entities
{
    public class Restaurant
    {
        public int Id { get; set; }
        public int CategoryId { get; set; }
        public string Title { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string WebsiteUrl { get; set; }
        public TimeSpan OpenHour { get; set; }
        public TimeSpan CloseHour { get; set; }
        public string OpenDays { get; set; }
        public string Address { get; set; }
        public string ImageUrl { get; set; }
        public DateTime CreatedDate { get; set; }


        public Category Category { get; set; }
        public ICollection<Dish> Dishes { get; set; } = new List<Dish>();
    }
}
