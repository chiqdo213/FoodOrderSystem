﻿namespace RestaurantManagement.Models.Entities
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime CreatedDate { get; set; }


        public ICollection<Restaurant> Restaurants { get; set; } = new List<Restaurant>();
    }
}
