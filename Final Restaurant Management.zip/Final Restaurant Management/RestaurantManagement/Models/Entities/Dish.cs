﻿namespace RestaurantManagement.Models.Entities
{
    public class Dish
    {
        public int Id { get; set; }
        public int RestaurantId { get; set; }
        public string Title { get; set; }
        public string Slogan { get; set; }
        public decimal Price { get; set; }
        public string Img { get; set; }

        public Restaurant Restaurant { get; set; }
        public ICollection<Remark> Remarks { get; set; } = new List<Remark>();
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }
}
