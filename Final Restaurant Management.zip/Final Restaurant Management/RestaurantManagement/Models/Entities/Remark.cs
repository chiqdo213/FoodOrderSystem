﻿using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantManagement.Models.Entities
{
    public class Remark
    {
        public int Id { get; set; }
        public int DishId { get; set; }
        public string Status { get; set; }
        public string RemarkText { get; set; }
        public DateTime RemarkDate { get; set; }
    }
}
