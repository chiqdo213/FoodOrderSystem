﻿using RestaurantManagement.Models.ApplicationIdentities;

namespace RestaurantManagement.Models.Entities
{
    public class Order
    {
        public int Id { get; set; }
        public Guid ApplicationUserId { get; set; }
        public string Status { get; set; }
        public DateTime OrderDate { get; set; }


        public ApplicationUser ApplicationUser { get; set; }
        public ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
    }
}
