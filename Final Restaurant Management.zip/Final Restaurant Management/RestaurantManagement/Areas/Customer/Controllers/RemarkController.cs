﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models.Consts;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Areas.Customer.Controllers
{
    [Area("Customer")]
    [Authorize]
    public class RemarkController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RemarkController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Create(int id)
        {
            var dish = await _context.Dishes.FindAsync(id);
            if (dish == null)
            {
                return NotFound();
            }

            var remark = new Remark
            {
                DishId = id,
                Status = SD.StatusCompleted,
                RemarkDate = DateTime.Now
            };
            Console.WriteLine($"DishId: {remark.DishId}, Status: {remark.Status}");

            ViewBag.Dish = dish;
            return View(remark);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DishId, Status, RemarkText, RemarkDate")] Remark remark)
        {
            if (!ModelState.IsValid)
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine(error.ErrorMessage);
                }
                var dish = await _context.Dishes.FindAsync(remark.DishId);
                ViewBag.Dish = dish;
                return View(remark);
            }

            var dishFromDb = await _context.Dishes.Include(d => d.Remarks).FirstOrDefaultAsync(d => d.Id == remark.DishId);
            if (dishFromDb == null)
            {
                return NotFound();
            }

            remark.RemarkDate = DateTime.Now;
            remark.Status = SD.StatusCompleted;

            _context.Remarks.Add(remark);
            await _context.SaveChangesAsync();

            return RedirectToAction("ThankYou");
        }

        public IActionResult ThankYou()
        {
            return View();
        }
    }
}