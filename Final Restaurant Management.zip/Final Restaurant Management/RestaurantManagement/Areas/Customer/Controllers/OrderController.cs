﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using RestaurantManagement.Models.ApplicationIdentities;
using RestaurantManagement.Models.Entities;
using RestaurantManagement.Data;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Models.Consts;

namespace RestaurantManagement.Areas.Customer.Controllers
{
    [Area("Customer")]
    [Authorize]
    public class OrderController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public OrderController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            var orders = new List<Order>();

            if (User.IsInRole(SD.Role_Admin))
            {
                orders = await _context.Orders
                    .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Dish)
                    .ToListAsync();
            }
            else if (User.IsInRole(SD.Role_User))
            {
                orders = await _context.Orders
                    .Where(o => o.ApplicationUserId == user.Id)
                    .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Dish)
                    .ToListAsync();
            }

            return View(orders);
        }

        public async Task<IActionResult> Details(int id)
        {
            var orderDetails = await _context.Orders
                .Where(o => o.Id == id)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Dish)
                .Select(o => new
                {
                    o.Id,
                    o.OrderDate,
                    o.Status,
                    FullName = o.OrderItems.FirstOrDefault().FullName ?? "N/A",
                    Phone = o.OrderItems.FirstOrDefault().Phone ?? "N/A",
                    Address = o.OrderItems.FirstOrDefault().Address ?? "N/A",
                    OrderItems = o.OrderItems.Select(oi => new
                    {
                        oi.Id,
                        oi.DishId,
                        oi.Title,
                        oi.Quantity,
                        oi.Price,
                        oi.TotalPrice,
                        Img = oi.Dish.Img
                    }).ToList()
                })
                .FirstOrDefaultAsync();

            if (orderDetails == null)
            {
                return NotFound();
            }

            return View(orderDetails);
        }

        public async Task<IActionResult> ApproveOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            order.Status = SD.StatusApproved;
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { id });
        }

        public async Task<IActionResult> CompleteOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            order.Status = SD.StatusCompleted;
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { id });
        }

        public async Task<IActionResult> CancelOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            order.Status = SD.StatusCanceled;
            await _context.SaveChangesAsync();

            return RedirectToAction("Details", new { id });
        }
    }
}
