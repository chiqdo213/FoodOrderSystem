﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models.ApplicationIdentities;
using RestaurantManagement.Models.Consts;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Areas.Customer.Controllers
{
    [Area("Customer")]
    [Authorize]
    public class CartController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public CartController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return Unauthorized();
            }

            var cart = await _context.Carts
                .Include(c => c.CartItems)
                .ThenInclude(ci => ci.Dish)
                .FirstOrDefaultAsync(c => c.ApplicationUserId == user.Id);

            return View(cart);
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(int dishId)
        {
            var user = await _userManager.GetUserAsync(User);

            if (user == null)
            {
                return Unauthorized();
            }

            var cart = _context.Carts.FirstOrDefault(c => c.ApplicationUserId == user.Id);
            if (cart == null)
            {
                cart = new Cart
                {
                    ApplicationUserId = user.Id,
                    CreatedDate = DateTime.Now
                };
                _context.Carts.Add(cart);
                await _context.SaveChangesAsync();
            }

            var cartItem = _context.CartItems.FirstOrDefault(ci => ci.CartId == cart.Id && ci.DishId == dishId);
            if (cartItem != null)
            {
                cartItem.Quantity += 1;
            }
            else
            {
                var dish = await _context.Dishes.FindAsync(dishId);
                if (dish == null)
                {
                    TempData["Error"] = "The dish does not exist.";
                    return RedirectToAction("Index", "Home");
                }

                cartItem = new CartItem
                {
                    CartId = cart.Id,
                    DishId = dish.Id,
                    Quantity = 1
                };

                _context.CartItems.Add(cartItem);
            }

            await _context.SaveChangesAsync();

            if (Request.Headers["X-Requested-With"] == "XMLHttpRequest")
            {
                return Json(new { success = true, message = "Item added to cart successfully!" });
            }

            TempData["Success"] = "Item added to cart!";
            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Checkout()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var cartItems = await _context.CartItems
                .Where(ci => ci.Cart.ApplicationUserId == user.Id)
                .Include(ci => ci.Dish)
                .ToListAsync();

            if (!cartItems.Any()) return RedirectToAction("Index");

            ViewBag.FullName = user.FullName;
            ViewBag.Phone = user.PhoneNumber;
            ViewBag.Address = user.Address;
            ViewBag.CartItems = cartItems;
            ViewBag.TotalPrice = cartItems.Sum(ci => ci.Quantity * ci.Dish.Price);

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Checkout(string fullName, string phone, string address)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var cartItems = await _context.CartItems
                .Where(ci => ci.Cart.ApplicationUserId == user.Id)
                .Include(ci => ci.Dish)
                .ToListAsync();

            if (!cartItems.Any()) return RedirectToAction("Index");

            var order = new Order
            {
                ApplicationUserId = user.Id,
                Status = SD.StatusPending,
                OrderDate = DateTime.Now,
                OrderItems = cartItems.Select(ci => new OrderItem
                {
                    DishId = ci.DishId,
                    Title = ci.Dish.Title,
                    Quantity = ci.Quantity,
                    Price = ci.Dish.Price,
                    TotalPrice = ci.Quantity * ci.Dish.Price,
                    FullName = fullName,
                    Phone = phone,
                    Address = address
                }).ToList()
            };

            _context.Orders.Add(order);
            _context.CartItems.RemoveRange(cartItems);
            await _context.SaveChangesAsync();

            return RedirectToAction("OrderSuccess");
        }

        public IActionResult OrderSuccess()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> IncreaseQuantity(int cartItemId)
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem != null)
            {
                cartItem.Quantity += 1;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> DecreaseQuantity(int cartItemId)
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem != null)
            {
                if (cartItem.Quantity > 1)
                {
                    cartItem.Quantity -= 1;
                }
                else
                {
                    _context.CartItems.Remove(cartItem);
                }
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> RemoveItem(int cartItemId)
        {
            var cartItem = await _context.CartItems.FindAsync(cartItemId);
            if (cartItem != null)
            {
                _context.CartItems.Remove(cartItem);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }

    }
}
