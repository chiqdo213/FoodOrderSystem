using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models;
using RestaurantManagement.Models.Entities;
using System.Diagnostics;

namespace RestaurantManagement.Areas.Customer.Controllers
{
    [Area("Customer")]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _logger = logger;
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> IndexAsync()
        {
            var dishes = await _context.Dishes
                .Include(d => d.Restaurant)
                .ThenInclude(r => r.Category)
                .ToListAsync();

            var restaurants = await _context.Restaurants
                .Include(r => r.Category)
                .ToListAsync();

            return View(new Tuple<IEnumerable<Dish>, IEnumerable<Restaurant>>(dishes, restaurants));
        }

        public async Task<IActionResult> AllDish()
        {
            var dishes = await _context.Dishes
                .Include(d => d.Restaurant)
                .ThenInclude(r => r.Category)
                .ToListAsync();
            return View(dishes);
        }

        public async Task<IActionResult> AllRestaurant()
        {
            var restaurants = await _context.Restaurants
                .Include(r => r.Category)
                .ToListAsync();
            return View(restaurants);
        }

        public async Task<IActionResult> DetailsDish(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dish = await _context.Dishes
                .Include(d => d.Restaurant)
                .Include(d => d.Remarks)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (dish == null)
            {
                return NotFound();
            }

            return View(dish);
        }

        public async Task<IActionResult> DetailsRestaurant(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var restaurant = await _context.Restaurants
                .Include(r => r.Category)
                .Include(r => r.Dishes)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (restaurant == null)
            {
                return NotFound();
            }

            return View(restaurant);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
