﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models.Consts;
using RestaurantManagement.Models.Entities;

namespace RestaurantManagement.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = SD.Role_Admin)]
    public class DishController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public DishController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            var dishes = await _context.Dishes
                .Include(d => d.Restaurant)
                .ThenInclude(r => r.Category)
                .ToListAsync();
            return View(dishes);
        }

        public IActionResult Create()
        {
            ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,RestaurantId,Title,Slogan,Price,Img")] Dish dish, IFormFile imageFile)
        {
            ModelState.Remove("Restaurant");
            ModelState.Remove("Img");

            foreach (var state in ModelState)
            {
                if (state.Value.Errors.Count > 0)
                {
                    Console.WriteLine($"Property: {state.Key}, Errors: {string.Join(", ", state.Value.Errors.Select(e => e.ErrorMessage))}");
                }
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (dish.RestaurantId <= 0)
                    {
                        ModelState.AddModelError("RestaurantId", "Please select a valid restaurant");
                        ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title");
                        return View(dish);
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "data");
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        dish.Img = "/images/data/" + uniqueFileName;
                    }
                    else
                    {
                        dish.Img = "/images/default-dish.jpg";
                    }

                    _context.Add(dish);
                    await _context.SaveChangesAsync();

                    Console.WriteLine($"Dish saved successfully with image: {dish.Img}");

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error creating dish: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while saving the dish: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Model state is invalid");
            }

            ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title", dish.RestaurantId);
            return View(dish);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dish = await _context.Dishes.FindAsync(id);
            if (dish == null)
            {
                return NotFound();
            }

            ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title", dish.RestaurantId);
            return View(dish);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,RestaurantId,Title,Slogan,Price,Img")] Dish dish, IFormFile? imageFile)
        {
            if (id != dish.Id)
            {
                return NotFound();
            }

            ModelState.Remove("Restaurant");
            ModelState.Remove("Img");

            if (ModelState.IsValid)
            {
                try
                {
                    if (dish.RestaurantId <= 0)
                    {
                        ModelState.AddModelError("RestaurantId", "Please select a valid restaurant");
                        ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title", dish.RestaurantId);
                        return View(dish);
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        if (!string.IsNullOrEmpty(dish.Img) && !dish.Img.Contains("default-dish.jpg"))
                        {
                            string oldImagePath = Path.Combine(_webHostEnvironment.WebRootPath, dish.Img.TrimStart('/'));
                            if (System.IO.File.Exists(oldImagePath))
                            {
                                try
                                {
                                    System.IO.File.Delete(oldImagePath);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine($"Could not delete old image: {ex.Message}");
                                }
                            }
                        }

                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "data");
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        dish.Img = "/images/data/" + uniqueFileName;
                    }

                    _context.Update(dish);
                    await _context.SaveChangesAsync();

                    Console.WriteLine($"Dish updated successfully with image: {dish.Img}");

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException ex)
                {
                    if (!DishExists(dish.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        Console.WriteLine($"Concurrency exception: {ex.Message}");
                        ModelState.AddModelError("", "The record was modified by another user. Please try again.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error updating dish: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while updating the dish: " + ex.Message);
                }
            }
            else
            {
                Console.WriteLine("Model state is invalid");
            }

            ViewData["RestaurantId"] = new SelectList(_context.Restaurants, "Id", "Title", dish.RestaurantId);
            return View(dish);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dish = await _context.Dishes
                .Include(d => d.Restaurant)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (dish == null)
            {
                return NotFound();
            }

            return View(dish);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dish = await _context.Dishes.FindAsync(id);
            if (dish != null)
            {
                if (!string.IsNullOrEmpty(dish.Img))
                {
                    string imagePath = Path.Combine(_webHostEnvironment.WebRootPath, dish.Img.TrimStart('/'));
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                _context.Dishes.Remove(dish);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool DishExists(int id)
        {
            return _context.Dishes.Any(e => e.Id == id);
        }
    }
}
