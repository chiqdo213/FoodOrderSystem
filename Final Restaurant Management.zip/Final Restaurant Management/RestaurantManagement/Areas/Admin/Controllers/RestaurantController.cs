﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models.Consts;
using RestaurantManagement.Models.Entities;
using RestaurantManagement.Models.Enums;

namespace RestaurantManagement.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = SD.Role_Admin)]
    public class RestaurantController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public RestaurantController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            var restaurants = await _context.Restaurants
                .Include(r => r.Category)
                .ToListAsync();
            return View(restaurants);
        }

        public IActionResult Create()
        {
            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,CategoryId,Title,Email,Phone,WebsiteUrl,OpenHour,CloseHour,OpenDays,Address,ImageUrl")] Restaurant restaurant, IFormFile imageFile)
        {
            ModelState.Remove("Category");
            ModelState.Remove("ImageUrl");

            if (ModelState.IsValid)
            {
                try
                {
                    if (restaurant.CategoryId <= 0)
                    {
                        ModelState.AddModelError("CategoryId", "Please select a valid category");
                        ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name");
                        return View(restaurant);
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "data");
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        restaurant.ImageUrl = "/images/data/" + uniqueFileName;
                    }
                    else
                    {
                        restaurant.ImageUrl = "/images/default-restaurant.jpg";
                    }

                    restaurant.CreatedDate = DateTime.Now;
                    _context.Add(restaurant);
                    await _context.SaveChangesAsync();

                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error creating restaurant: {ex.Message}");
                    ModelState.AddModelError("", "An error occurred while saving the restaurant.");
                }
            }

            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name", restaurant.CategoryId);
            return View(restaurant);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var restaurant = await _context.Restaurants.FindAsync(id);
            if (restaurant == null)
            {
                return NotFound();
            }

            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name", restaurant.CategoryId);
            return View(restaurant);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,CategoryId,Title,Email,Phone,WebsiteUrl,OpenHour,CloseHour,OpenDays,Address,ImageUrl,CreatedDate")] Restaurant restaurant, IFormFile? imageFile)
        {
            if (id != restaurant.Id)
            {
                return NotFound();
            }

            ModelState.Remove("Category");
            ModelState.Remove("ImageUrl");
            ModelState.Remove("Dishes");

            if (ModelState.IsValid)
            {
                try
                {
                    if (restaurant.CategoryId <= 0)
                    {
                        ModelState.AddModelError("CategoryId", "Please select a valid category");
                        ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name", restaurant.CategoryId);
                        return View(restaurant);
                    }

                    if (imageFile != null && imageFile.Length > 0)
                    {
                        string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "images", "data");
                        string uniqueFileName = Guid.NewGuid().ToString() + Path.GetExtension(imageFile.FileName);
                        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        if (!Directory.Exists(uploadsFolder))
                        {
                            Directory.CreateDirectory(uploadsFolder);
                        }

                        using (var fileStream = new FileStream(filePath, FileMode.Create))
                        {
                            await imageFile.CopyToAsync(fileStream);
                        }

                        if (!string.IsNullOrEmpty(restaurant.ImageUrl) && !restaurant.ImageUrl.Contains("default-restaurant.jpg"))
                        {
                            string oldImagePath = Path.Combine(_webHostEnvironment.WebRootPath, restaurant.ImageUrl.TrimStart('/'));
                            if (System.IO.File.Exists(oldImagePath))
                            {
                                System.IO.File.Delete(oldImagePath);
                            }
                        }

                        restaurant.ImageUrl = "/images/data/" + uniqueFileName;
                    }

                    _context.Update(restaurant);
                    await _context.SaveChangesAsync();

                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RestaurantExists(restaurant.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        ModelState.AddModelError("", "The record was modified by another user. Please try again.");
                    }
                }
                catch (Exception ex)
                {
                    ModelState.AddModelError("", "An error occurred while updating the restaurant: " + ex.Message);
                }
            }

            ViewData["CategoryId"] = new SelectList(_context.Categories, "Id", "Name", restaurant.CategoryId);
            return View(restaurant);
        }

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var restaurant = await _context.Restaurants
                .Include(r => r.Category)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (restaurant == null)
            {
                return NotFound();
            }

            return View(restaurant);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var restaurant = await _context.Restaurants.FindAsync(id);
            if (restaurant != null)
            {
                if (!string.IsNullOrEmpty(restaurant.ImageUrl))
                {
                    string imagePath = Path.Combine(_webHostEnvironment.WebRootPath, restaurant.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(imagePath))
                    {
                        System.IO.File.Delete(imagePath);
                    }
                }

                _context.Restaurants.Remove(restaurant);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool RestaurantExists(int id)
        {
            return _context.Restaurants.Any(e => e.Id == id);
        }
    }
}
