﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RestaurantManagement.Data;
using RestaurantManagement.Models.Consts;

namespace RestaurantManagement.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Authorize(Roles = SD.Role_Admin)]
    public class DashBoardController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DashBoardController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var orderItems = await _context.OrderItems
                .Include(oi => oi.Dish)
                .Include(oi => oi.Order)
                .Where(oi => oi.Order.Status == SD.StatusCompleted)
                .ToListAsync();

            var topDishes = orderItems
                .GroupBy(oi => new { oi.DishId, oi.Dish.Title, oi.Dish.Price, oi.Dish.Img })
                .Select(g => new
                {
                    DishId = g.Key.DishId,
                    DishName = g.Key.Title,
                    Image = g.Key.Img,
                    TotalQuantity = g.Sum(x => x.Quantity),
                    TotalRevenue = g.Sum(x => x.Quantity * g.Key.Price)
                })
                .OrderByDescending(x => x.TotalQuantity)
                .Take(3)
                .ToList();

            var revenueByDish = orderItems
                .GroupBy(oi => new { oi.DishId, oi.Dish.Title, oi.Dish.Price })
                .Select(g => new
                {
                    DishName = g.Key.Title,
                    TotalRevenue = g.Sum(x => x.Quantity * g.Key.Price)
                })
                .ToList();

            var soldDishes = orderItems
                .GroupBy(oi => new { oi.DishId, oi.Dish.Title, oi.Dish.Price })
                .Select(g => new
                {
                    DishName = g.Key.Title,
                    TotalQuantity = g.Sum(x => x.Quantity),
                    TotalRevenue = g.Sum(x => x.Quantity * g.Key.Price)
                })
                .OrderByDescending(x => x.TotalQuantity)
                .ToList();

            ViewBag.DishNames = revenueByDish.Select(x => x.DishName).ToList();
            ViewBag.DishRevenues = revenueByDish.Select(x => x.TotalRevenue).ToList();

            ViewBag.TopDishes = topDishes;
            ViewBag.RevenueByDish = revenueByDish;
            ViewBag.SoldDishes = soldDishes;

            return View();
        }
    }
}
